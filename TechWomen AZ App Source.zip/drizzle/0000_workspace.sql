CREATE TABLE IF NOT EXISTS profiles (
  space TEXT NOT NULL,
  id TEXT NOT NULL,
  name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('Mentor', 'Mentee')),
  focus TEXT NOT NULL DEFAULT '',
  color TEXT NOT NULL DEFAULT 'lilac',
  PRIMARY KEY (space, id)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS threads (
  id TEXT PRIMARY KEY,
  space TEXT NOT NULL,
  title TEXT NOT NULL,
  updated_at INTEGER NOT NULL,
  direct_key TEXT,
  creation_key TEXT NOT NULL,
  UNIQUE (space, direct_key)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS members (
  thread_id TEXT NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL,
  last_read INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (thread_id, user_id)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  thread_id TEXT NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
  author_id TEXT NOT NULL,
  body TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS events (
  id TEXT PRIMARY KEY,
  space TEXT NOT NULL,
  owner_id TEXT NOT NULL,
  title TEXT NOT NULL,
  starts_at INTEGER NOT NULL,
  ends_at INTEGER NOT NULL,
  format TEXT NOT NULL CHECK (format IN ('Online', 'In person')),
  location TEXT NOT NULL DEFAULT '',
  visibility TEXT NOT NULL CHECK (visibility IN ('Public', 'Private')),
  reminder INTEGER NOT NULL,
  notes TEXT NOT NULL DEFAULT ''
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS event_guests (
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL,
  PRIMARY KEY (event_id, user_id)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS reminder_reads (
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL,
  PRIMARY KEY (event_id, user_id)
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS thread_space ON threads(space, updated_at);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS message_date ON messages(thread_id, created_at);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS member_lookup ON members(user_id, thread_id);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS event_date ON events(space, starts_at);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS ai_usage (
  space TEXT NOT NULL,
  user_id TEXT NOT NULL,
  slot INTEGER NOT NULL,
  requests INTEGER NOT NULL,
  PRIMARY KEY (space, user_id)
);
