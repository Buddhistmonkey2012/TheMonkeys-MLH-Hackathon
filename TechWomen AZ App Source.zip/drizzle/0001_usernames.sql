ALTER TABLE profiles ADD COLUMN username TEXT;
--> statement-breakpoint
CREATE UNIQUE INDEX profiles_username ON profiles(space, username COLLATE NOCASE);
