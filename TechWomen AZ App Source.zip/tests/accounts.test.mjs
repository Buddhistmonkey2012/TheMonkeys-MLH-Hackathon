import assert from 'node:assert/strict';
import { createHash, generateKeyPairSync, sign } from 'node:crypto';
import { test } from 'node:test';
import { createAuth } from '../auth.mjs';
import { openDatabase } from '../local-db.mjs';
import { createLocalApplication } from '../local-app.mjs';

const password = 'violet-clover-aurora';
const setCookie = (response, name) => response.headers.getSetCookie().find(value => value.startsWith(name + '='));
const cookiePair = value => value.split(';')[0];
const jsonHeaders = origin => ({origin,'Content-Type':'application/json'});

test('Email account registration, profile setup, sign-in, and sign-out through the app routes', async t => {
  const {DB,close} = await openDatabase(':memory:');
  t.after(close);
  const base = 'https://mentoring.example.test';
  const app = createLocalApplication({DB,origin:base,accounts:true});
  const call = (path,init) => app(new Request(base + path,init),'127.0.0.1');
  const post = (route, body, session, origin = base) => call(route,{
    method:'POST',headers:{...jsonHeaders(origin),...(session ? {cookie:session} : {})},body:JSON.stringify(body),
  });
  const state = cookie => call('/api/state?mode=demo&as=maya',
    {headers:cookie ? {cookie} : {'oai-authenticated-user-id':'forged-user'}});
  assert.equal((await state()).status,401);
  assert.deepEqual(await (await call('/auth/status')).json(),{accounts:true,signedIn:false,googleAvailable:false});
  const account = {name:'Alex Rivera',email:'Alex@example.test',password};
  assert.equal((await post('/auth/register',account,undefined,'https://elsewhere.test')).status,403);
  assert.equal((await post('/auth/register',{...account,password:'short'})).status,400);
  const registered = await post('/auth/register',account);
  assert.equal(registered.status,201);
  const sessionCookie = setCookie(registered,'tw_session');
  assert.match(sessionCookie,/HttpOnly; SameSite=Lax.*; Secure$/);
  const session = cookiePair(sessionCookie);
  const newAccount = await (await state(session)).json();
  assert.equal(newAccount.signedIn.name,account.name);
  assert.equal(newAccount.signedIn.accounts,true);
  assert.equal(newAccount.profile,null);
  assert.equal(newAccount.people.length,0);
  assert.equal((await post('/api/profile',{name:account.name,username:'Alex_R',role:'Mentee',focus:'Data analytics'},session)).status,200);
  assert.equal((await (await state(session)).json()).profile.username,'alex_r');
  assert.equal((await (await state(session)).json()).profile.focus,'Data analytics');
  assert.equal((await post('/auth/register',account)).status,409);
  assert.equal((await post('/auth/sign-out',{},session)).status,200);
  assert.equal((await state(session)).status,401);
  assert.equal((await post('/auth/sign-in',{...account,password:'different-password'})).status,401);
  const signedIn = await post('/auth/sign-in',{...account,email:'alex@example.test'});
  assert.equal(signedIn.status,200);
  const nextSession = cookiePair(setCookie(signedIn,'tw_session'));
  assert.notEqual(nextSession,session);
  assert.equal((await (await state(nextSession)).json()).profile.name,account.name);
});

test('Google callback requires its browser state, validates identity, and links the existing account explicitly', async t => {
  const database = await openDatabase(':memory:');
  t.after(database.close);
  const origin = 'https://mentoring.example.test';
  const client = 'fake-client.apps.googleusercontent.com';
  const profile = {sub:'alex-google-subject',email:'alex@example.test',email_verified:true,name:'Alex Google'};
  const {privateKey,publicKey} = generateKeyPairSync('rsa',{modulusLength:2048});
  const key = {...publicKey.export({format:'jwk'}),kid:'fixture-key',alg:'RS256'};
  const exchanges = new Map();
  const encode = data => Buffer.from(JSON.stringify(data)).toString('base64url');
  const googleFetch = async (url,options) => {
    if (url.endsWith('/certs')) return Response.json({keys:[key]});
    assert.equal(url,'https://oauth2.googleapis.com/token');
    const {claims,authorization} = exchanges.get(options.body.get('code'));
    const challenge = createHash('sha256').update(options.body.get('code_verifier')).digest('base64url');
    assert.equal(challenge,authorization.searchParams.get('code_challenge'));
    assert.equal(options.body.get('redirect_uri'),origin + '/auth/google/callback');
    const now = Math.floor(Date.now()/1000);
    const input = encode({alg:'RS256',kid:key.kid}) + '.' + encode({
      iss:'https://accounts.google.com',aud:client,iat:now,exp:now+600,
      nonce:authorization.searchParams.get('nonce'),...claims,
    });
    return Response.json({id_token:input + '.' + sign('RSA-SHA256',Buffer.from(input),privateKey).toString('base64url')});
  };
  const auth = createAuth({DB:database.DB,origin,googleClientId:client,googleClientSecret:'unused-fixture-secret',googleFetch});
  const request = (target,init) => new Request(origin + target,init);
  const call = req => auth.handle(req,'127.0.0.1');
  const registered = await call(request('/auth/register',{
    method:'POST',headers:jsonHeaders(origin),body:JSON.stringify({email:profile.email,name:'Alex Local',password}),
  }));
  const localCookie = cookiePair(setCookie(registered,'tw_session'));
  const local = await auth.getAccount(request('/',{headers:{cookie:localCookie}}));
  let attempt = 0;
  async function start(claims, session) {
    const opened = await call(request('/auth/google' + (session ? '?link=1' : ''),{headers:session ? {cookie:session} : {}}));
    assert.equal(opened.status,303);
    const authorization = new URL(opened.headers.get('Location'));
    assert.equal(authorization.origin,'https://accounts.google.com');
    assert.equal(authorization.searchParams.get('code_challenge_method'),'S256');
    const code = 'fixture-' + (++attempt);
    exchanges.set(code,{claims,authorization});
    const google = cookiePair(setCookie(opened,'tw_google_state'));
    return {
      callback:'/auth/google/callback?code=' + code + '&state=' + authorization.searchParams.get('state'),
      cookie:session ? session + '; ' + google : google,
    };
  }
  const finish = ({callback,cookie}) => call(request(callback,{headers:{cookie}}));
  const unlinked = await start(profile);
  assert.equal((await call(request(unlinked.callback))).headers.get('Location'),'/?auth=google_retry');
  assert.equal((await finish(unlinked)).headers.get('Location'),'/?auth=link_existing');
  assert.equal((await finish(unlinked)).headers.get('Location'),'/?auth=google_retry');
  assert.equal((await finish(await start({...profile,aud:'another-client'}))).headers.get('Location'),'/?auth=google_retry');
  assert.equal((await finish(await start({...profile,email:'different@example.test'},localCookie))).headers.get('Location'),'/?auth=google_email_mismatch');
  assert.equal((await finish(await start(profile,localCookie))).headers.get('Location'),'/?auth=google_connected');
  const signedIn = await finish(await start({...profile,email:'updated@example.test'}));
  assert.equal(signedIn.headers.get('Location'),'/?auth=signed_in');
  assert.equal(signedIn.headers.getSetCookie().length,2);
  const federatedCookie = setCookie(signedIn,'tw_session');
  assert.match(federatedCookie,/; Secure$/);
  const linked = await auth.getAccount(request('/',{headers:{cookie:cookiePair(federatedCookie)}}));
  assert.equal(linked.id,local.id);
  assert.equal(linked.name,'Alex Local');
  const firstUse = await finish(await start({sub:'sam-google',email:'sam@example.test',email_verified:true,name:'Sam Google'}));
  const created = await auth.getAccount(request('/',{headers:{cookie:cookiePair(setCookie(firstUse,'tw_session'))}}));
  assert.equal(created.name,'Sam Google');
  assert.notEqual(created.id,local.id);
});
