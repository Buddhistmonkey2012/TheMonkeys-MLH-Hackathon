import assert from 'node:assert/strict';
import { test } from 'node:test';
import { handleApi } from '../api.js';
import { openDatabase } from '../local-db.mjs';

test('Mentoring groups, calendar visibility, reminders, and assistant access', async t => {
  const {DB,close} = await openDatabase(':memory:');
  t.after(close);
  const base = 'http://127.0.0.1:4173';
  async function call(as, route, body, params) {
    const query = new URLSearchParams({as,...params});
    const headers = {'oai-authenticated-user-id':as,'Content-Type':'application/json'};
    const request = new Request(base + '/api/' + route + '?' + query, {headers,...(body === undefined ? {} : {
      method:'POST',body:JSON.stringify(body),
    })});
    const response = await handleApi(request,{DB});
    return {status:response.status, data:await response.json()};
  }
  const data = async (...args) => {
    const result = await call(...args);
    assert.equal(result.status,200,JSON.stringify(result.data));
    return result.data;
  };
  const seed = await data('avery','state');
  assert.deepEqual(seed.people,[]);
  assert.deepEqual(seed.threads,[]);
  for (const [id,role] of [['avery','Mentee'],['maya','Mentor'],['jordan','Mentor'],['sofia','Mentee']]) {
    await data(id,'profile',{name:id,username:id,role});
  }
  assert.equal((await call('sofia','profile',{name:'sofia',username:'AVERY',role:'Mentee'})).status,409);
  const intake = {style:'One-on-one',format:'Online'};
  await data('avery','profile',{name:'avery',username:'avery',preferred:'Av',role:'Mentee',story:'I want to learn SQL and data analytics.',...intake});
  await data('maya','profile',{name:'maya',username:'maya',preferred:'Maya',role:'Mentor',story:'I teach data analysis with SQL.',...intake});
  await data('jordan','profile',{name:'jordan',username:'jordan',preferred:'Jordan',role:'Mentor',story:'I work in cybersecurity.',...intake});
  const matching = await data('avery','state');
  assert.deepEqual(matching.matches.map(m => m.id),['maya']);
  assert.deepEqual(matching.matches[0].common,['Data and analytics']);
  assert.deepEqual(matching.matches[0].preferences,['One-on-one','Online']);
  assert.ok(matching.people.every(person => !person.intake));
  const direct = await data('avery','new-thread',{people:['maya']});
  assert.equal(direct.id,(await data('avery','state')).threads[0].id);
  const requestId = crypto.randomUUID();
  const [first,second] = await Promise.all([
    data('avery','new-thread',{people:['jordan'], requestId}),
    data('jordan','new-thread',{people:['avery']}),
  ]);
  assert.equal(first.id,second.id);
  assert.equal((await call('avery','new-thread',{people:['sofia']})).status,400);
  const cohort = await data('maya','new-thread',{title:'A mentor and two mentees',people:['avery','sofia']});
  const support = await data('avery','new-thread',{title:'Two mentors and a mentee',people:['maya','jordan']});
  assert.ok((await data('sofia','state')).threads.some(thread => thread.id === cohort.id));
  assert.equal((await call('sofia','thread',undefined,{id:support.id})).status,404);
  assert.equal((await call('sofia','new-thread',{title:'Try to join',people:['maya','jordan','avery'],requestId:support.id})).status,404);
  assert.equal((await call('sofia','assistant',{thread:support.id,task:'summary'})).status,404);
  const message = {thread:support.id,message:'I’ll bring the portfolio draft.',id:crypto.randomUUID()};
  await data('avery','send',message);
  await data('avery','send',message);
  const reply = await data('jordan','thread',undefined,{id:support.id});
  assert.equal(reply.messages.length,1);
  assert.equal(reply.messages[0].body,message.message);
  assert.equal((await data('jordan','state')).threads.find(thread => thread.id === support.id).unread,1);
  await data('jordan','read',{thread:support.id,through:reply.messages[0].created_at});
  assert.equal((await data('jordan','state')).threads.find(thread => thread.id === support.id).unread,0);
  assert.equal((await data('jordan','assistant',{thread:support.id,task:'summary'})).source,'template');

  const starts_at = Date.now() + 180000;
  const event = {
    title:'Private check-in', starts_at, ends_at:starts_at + 1800000,
    visibility:'Private', format:'Online', location:'https://example.net/check-in', reminder:15, guests:['maya'],
    requestId:crypto.randomUUID(),
  };
  const create = await data('avery','event',event);
  assert.equal((await data('avery','event',event)).id,create.id);
  const seesEvent = async person => (await data(person,'state')).events.filter(e => e.id === create.id);
  assert.equal((await seesEvent('avery')).length,1);
  assert.equal((await seesEvent('maya')).length,1);
  assert.equal((await seesEvent('sofia')).length,0);
  assert.equal((await call('maya','event',{...event,id:create.id})).status,404);
  await data('maya','dismiss',{id:create.id});
  assert.ok((await data('maya','state')).readReminders.includes(create.id));
  assert.ok(!(await data('avery','state')).readReminders.includes(create.id));
  const changed = {...event,id:create.id,title:'Public networking meetup',visibility:'Public',format:'In person',location:'Phoenix, AZ'};
  await data('avery','event',changed);
  assert.equal((await seesEvent('sofia'))[0].format,'In person');
  assert.deepEqual((await seesEvent('sofia'))[0].guests,[]);
  await data('avery','event',{...changed,visibility:'Private',guests:[]});
  assert.equal((await seesEvent('maya')).length,0);
  await data('avery','delete-event',{id:create.id});
  assert.equal((await seesEvent('avery')).length,0);
});
