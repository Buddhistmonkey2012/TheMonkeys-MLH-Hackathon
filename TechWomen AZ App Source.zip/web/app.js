import { icon } from './icons.js';
import { accountScreen, googleButton } from './accounts.js';

const app = document.querySelector('#app');
const modal = document.querySelector('#modal');
const toastNode = document.querySelector('#toast');
const demoApi = globalThis.techWomenDemo;
const storage = {
  get(key) { try { return localStorage.getItem(key); } catch { return null; } },
  set(key,value) { try { localStorage.setItem(key,value); } catch {} },
};
const pages = {messages:'Messages', calendar:'Calendar', people:'People'};
const state = {
  page:'messages', mode:demoApi ? 'demo' : 'live', as:'',
  data:null, active:null, messages:[], filter:'', messageFilter:'all', calendar:'all',
  month:new Date(new Date().getFullYear(),new Date().getMonth(),1), mobileThread:false,
  drafts:new Map(), loadingThread:false, menu:false,
  auth:null, accountKind:'sign-in', accountNotice:'', savedDemoAccounts:[],
};
const googleNotices = {
  google_setup:'Google sign-in is waiting for server setup.',
  google_retry:'Google sign-in could not finish. Please try again.',
  google_cancelled:'Google sign-in was cancelled.',
  google_connected:'Your Google account is connected.',
  google_in_use:'That Google account is already connected to another workspace account.',
  google_email_mismatch:'Choose the Google account with the same email as your workspace account.',
  link_existing:'Sign in with your password first, then choose Connect Google account in your profile.',
  sign_in_first:'Sign in to your workspace before connecting Google.',
  try_later:'Too many sign-in attempts. Try again in a few minutes.',
};
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const attr = esc;
const fmt = (value, options) => new Intl.DateTimeFormat('en-US', options).format(new Date(value));
const shortTime = value => fmt(value,{hour:'numeric',minute:'2-digit'});
const dayText = value => fmt(value,{weekday:'short',month:'short',day:'numeric'});
const dayKey = value => fmt(value,{year:'numeric',month:'2-digit',day:'2-digit'});
const timezone = () => fmt(Date.now(),{timeZoneName:'short'}).split(', ').pop().split(' ').pop();
const pById = id => state.data?.people.find(p => p.id === id);
const activeThread = () => state.data?.threads.find(t => t.id === state.active);
const mine = () => state.data?.profile;
const firstName = name => name?.trim().split(/\s+/)[0] || 'there';
const isAttending = event => event.owner_id === mine()?.id || event.guests.includes(mine()?.id);
const dueReminders = () => (state.data?.events || []).filter(e => isAttending(e) && e.reminder > 0
  && e.starts_at - e.reminder * 60000 <= Date.now() && e.ends_at >= Date.now() && !state.data.readReminders.includes(e.id));
const upcoming = () => (state.data?.events || []).filter(e => e.starts_at >= Date.now() && (isAttending(e) || e.visibility === 'Public'));
const names = t => t.members.filter(id => id !== mine()?.id).map(id => pById(id)?.name || 'Member');
const titleOf = t => t.title || names(t).join(', ') || 'Conversation';
const colors = ['lilac','mint','peach','rose','gold'];
const avatar = (person, size = '') => {
  const initials = String(person?.name || '?').split(/\s+/).slice(0,2).map(part => part[0]).join('').toUpperCase();
  return `<span class="avatar ${colors.includes(person?.color) ? person.color : 'lilac'} ${size}" aria-hidden="true">${esc(initials)}</span>`;
};
const threadAvatar = (thread, size) => thread.members.length > 2
  ? `<span class="avatar cluster ${size || ''}">${icon('users',18)}</span>`
  : avatar(pById(thread.members.find(id => id !== mine()?.id)), size);
const compactDate = date => dayKey(date) === dayKey(Date.now()) ? shortTime(date) : fmt(date,{month:'short',day:'numeric'});
const iconButton = (name, label, action, extra = '') =>
  `<button type="button" class="icon-button ${extra}" aria-label="${attr(label)}" title="${attr(label)}" data-action="${action}">${icon(name)}</button>`;

async function api(route, body, parameters = {}) {
  if (demoApi) return demoApi(state.as,route,body,parameters);
  const query = new URLSearchParams({mode:state.mode,as:state.as,...parameters});
  const response = await fetch('/api/' + route + '?' + query, body === undefined ? {} : {
    method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),
  });
  const data = await response.json();
  if (!response.ok) {
    const error = new Error(data.error || 'Something went wrong.');
    error.status = response.status;
    throw error;
  }
  return data;
}

async function authPost(action, body = {}) {
  const response = await fetch('/auth/' + action,{
    method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'The account request could not be completed.');
  return result;
}
async function getAuthStatus() {
  const response = await fetch('/auth/status');
  if (!response.ok) return null;
  const data = await response.json();
  return data.accounts ? data : null;
}
async function renderAccountGate(focus = false) {
  if (state.auth.offline) {
    const result = await demoApi(null,'demo-accounts');
    state.savedDemoAccounts = result.accounts;
  }
  app.innerHTML = accountScreen({
    offline:state.auth.offline,kind:state.accountKind,accounts:state.savedDemoAccounts,
    available:state.auth.googleAvailable,notice:state.accountNotice,
  },esc);
  if (focus) document.querySelector('#auth-title')?.focus();
}
async function openDemoAccount(person) {
  storage.set('tw.demo.session',person);
  state.auth.signedIn = true;
  await changeWorkspace('demo',person);
}
async function accountSignOut() {
  if (state.auth.offline) storage.set('tw.demo.session','');
  else await authPost('sign-out');
  refreshCount++;
  Object.assign(state,{auth:{...state.auth,signedIn:false},data:null,active:null,messages:[],drafts:new Map(),accountKind:'sign-in',accountNotice:''});
  if (modal.open) modal.close();
  await renderAccountGate(true);
}

let toastTimer;
function toast(message) {
  toastNode.textContent = message;
  toastNode.classList.add('shown');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastNode.classList.remove('shown'),4000);
}
let refreshCount = 0;
async function refresh({full = false} = {}) {
  const count = ++refreshCount;
  const next = await api('state');
  if (count !== refreshCount) return;
  const changed = JSON.stringify(state.data) !== JSON.stringify(next);
  state.data = next;
  if (!state.data.threads.some(t => t.id === state.active)) state.active = state.data.threads[0]?.id || null;
  if (full) render();
  else if (changed && state.page === 'messages') updateInbox();
  else if (changed && !modal.open) render();
  updateBadges();
}
async function loadMessages({mark = true, forceBottom = false} = {}) {
  const id = state.active;
  const viewIdentifier = state.mode + state.as;
  if (!id || state.page !== 'messages') return;
  const data = await api('thread',undefined,{id});
  if (state.active !== id || state.mode + state.as !== viewIdentifier) return;
  const changed = JSON.stringify(state.messages) !== JSON.stringify(data.messages);
  state.loadingThread = false;
  state.messages = data.messages;
  if (changed || forceBottom) updateMessages(forceBottom);
  const latest = data.messages.at(-1);
  if (mark && latest && activeThread()?.unread) {
    await api('read',{thread:id, through:latest.created_at});
    if (state.active === id && activeThread()) {
      activeThread().unread = 0;
      updateInbox();
      updateBadges();
    }
  }
}
function updateBadges() {
  const bell = document.querySelector('#bell');
  if (bell) {
    const count = dueReminders().length;
    bell.querySelector('.notification-dot').hidden = !count;
    bell.setAttribute('aria-label', count ? 'Reminders, ' + count + ' unread' : 'Reminders');
  }
  const badge = document.querySelector('#nav-unread');
  if (badge) {
    badge.textContent = state.data.threads.filter(t => t.unread).length;
    badge.hidden = badge.textContent === '0';
  }
}

function sidebar() {
  return `<aside class="sidebar ${state.menu ? 'revealed' : ''}">
    <div class="brand"><img src="/mark.svg" alt="" width="43" height="43"><div><strong>TechWomen</strong><span>ARIZONA</span></div></div>
    <nav aria-label="Workspace">
      <p class="nav-label">WORKSPACE</p>
      ${Object.entries(pages).map(([key,label]) => `<button class="nav-item ${state.page === key ? 'current' : ''}" type="button" data-action="page" data-id="${key}" ${state.page === key ? 'aria-current="page"' : ''}>${icon(key === 'people' ? 'users' : key)}<span>${label}</span>${key === 'messages' ? '<span class="nav-count" id="nav-unread" hidden></span>' : ''}</button>`).join('')}
    </nav>
    <div class="side-bottom">
      ${state.mode === 'demo' ? '<div class="mode-note"><span class="mode-dot"></span> ' + (mine().isDemoAccount ? 'Demo account' : 'Demo workspace') + '</div>' : ''}
      <button class="profile-switch" type="button" data-action="profile-menu">
        ${avatar(mine(),'small')}<span><strong>${esc(mine().name)}</strong><small>${esc(mine().role)}</small></span>${icon('dots',18)}
      </button>
    </div>
  </aside>`;
}
function header() {
  return `<header class="topbar">
    ${iconButton('menu','Open workspace navigation','menu','mobile-menu')}
    <div class="crumb"><span>Workspace</span>${icon('chevron',14)}<strong>${pages[state.page]}</strong></div>
    <div class="top-actions">
      <button id="bell" class="icon-button bell" type="button" data-action="reminders" aria-label="Reminders" title="Reminders">${icon('bell')}<span class="notification-dot" hidden></span></button>
      ${state.page === 'messages' ? '<button class="button primary" type="button" data-action="new-thread">' + icon('plus',17) + '<span>New message</span></button>' : ''}
      ${state.page === 'calendar' ? '<button class="button primary" type="button" data-action="event-new">' + icon('plus',17) + '<span>New event</span></button>' : ''}
    </div>
  </header>`;
}
function hero() {
  return `<section class="hero" aria-labelledby="welcome">
    <div class="hero-content">
      <div class="hero-label"><span></span> MENTORSHIP WORKSPACE</div>
      <h1 id="welcome">Good to see you, ${esc(mine().intake?.preferred || firstName(mine().name))}.</h1>
      <p>Stay connected and take the next step on your path into tech.</p>
    </div>
    <div class="hero-art" aria-hidden="true">
      <i class="ring r1"></i><i class="ring r2"></i><i class="ring r3"></i><i class="ring r4"></i>
      <b class="star main-star">✦</b><b class="star small-star">✦</b><b class="star tiny-star">✧</b><i class="orbit-dot"></i>
    </div>
  </section>`;
}
function threadList() {
  const threads = state.data.threads.filter(t =>
    (state.messageFilter === 'all' || (state.messageFilter === 'unread' ? t.unread : t.members.length > 2)) &&
    [titleOf(t), names(t).join(' '), t.preview || ''].join(' ').toLowerCase().includes(state.filter.toLowerCase()));
  return threads.length ? threads.map(t => `<button type="button" class="thread-item ${t.id === state.active ? 'selected' : ''}" aria-pressed="${t.id === state.active}" data-action="thread" data-id="${attr(t.id)}">
    ${threadAvatar(t,'small')}<span class="thread-summary"><strong>${esc(titleOf(t))}</strong><span>${esc(t.preview || 'Start the conversation')}</span></span>
    <span class="thread-meta"><time datetime="${new Date(t.updated_at).toISOString()}">${esc(compactDate(t.updated_at))}</time>${t.unread ? '<i aria-label="Unread"></i>' : ''}</span>
  </button>`).join('') : '<p class="small-empty">No conversations match.</p>';
}
function messageContent() {
  if (state.loadingThread) return '<p class="small-empty">Opening conversation…</p>';
  if (!state.messages.length) return '<div class="empty"><span class="tile">' + icon('messages',23) + '</span><h3>Start the conversation</h3><p>Share an introduction or one goal you’d like to discuss.</p></div>';
  return state.messages.map((m,i) => {
    const me = m.author_id === mine().id;
    const person = pById(m.author_id);
    const prev = state.messages[i-1];
    const separated = !prev || dayKey(prev.created_at) !== dayKey(m.created_at);
    const label = dayKey(m.created_at) === dayKey(Date.now()) ? 'Today' : dayText(m.created_at);
    return `${separated ? '<div class="day-divider"><span>' + esc(label) + '</span></div>' : ''}<article class="message ${me ? 'mine' : ''}">
      ${me ? '' : avatar(person,'tiny')}
      <div class="bubble-group"><div class="message-meta"><strong>${esc(me ? 'You' : person?.name || 'Member')}</strong><time datetime="${new Date(m.created_at).toISOString()}">${esc(shortTime(m.created_at))}</time></div><div class="bubble">${esc(m.body)}</div></div>
    </article>`;
  }).join('');
}
function conversation() {
  const t = activeThread();
  if (!t) return '<div class="empty conversation-empty"><span class="tile">' + icon('messages',24) + '</span><h3>Your conversations start here</h3><p>Send a message to a mentor or start a mentoring group.</p><button class="button primary" type="button" data-action="new-thread">' + icon('plus',16) + ' New message</button></div>';
  const partner = pById(t.members.find(id => id !== mine()?.id));
  const description = t.members.length === 2
    ? [partner?.role, partner?.focus].filter(Boolean).join(' · ')
    : t.members.length + ' members · ' + names(t).map(firstName).join(', ');
  return `<div class="conversation">
    <header class="conversation-head">
      ${iconButton('left','Back to conversations','back','mobile-back')}
      ${threadAvatar(t,'medium')}
      <div class="conversation-title"><h3>${esc(titleOf(t))}</h3><p>${esc(description)}</p></div>
      <button class="button outline compact" type="button" data-action="thread-event">${icon('calendar',17)}<span>Schedule</span></button>
    </header>
    <div class="message-stream" id="message-stream" role="log" aria-label="Conversation messages">${messageContent()}</div>
    <form class="composer" id="composer"><label class="sr-only" for="draft">Message</label><textarea maxlength="3000" rows="1" id="draft" placeholder="Write a message…">${esc(state.drafts.get(t.id) || '')}</textarea><button class="send" type="submit" aria-label="Send message" title="Send message">${icon('send',18)}</button></form>
  </div>`;
}
function upcomingItem(e) {
  return `<button type="button" class="upcoming-item" data-action="event-view" data-id="${attr(e.id)}">
    <span class="date-tile"><span>${esc(fmt(e.starts_at,{month:'short'}))}</span><strong>${esc(fmt(e.starts_at,{day:'numeric'}))}</strong></span>
    <span class="upcoming-text"><strong>${esc(e.title)}</strong><small>${esc(fmt(e.starts_at,{weekday:'short'}))} · ${esc(shortTime(e.starts_at))}</small><span class="format ${e.format === 'In person' ? 'in-person' : ''}">${icon(e.format === 'Online' ? 'video' : 'pin',13)}${esc(e.format)}</span></span>
  </button>`;
}
function rail() {
  const events = upcoming().slice(0,2);
  return `<aside class="rail" aria-label="Meetings and assistant">
    <section class="panel next-panel"><div class="rail-title"><span class="tile green">${icon('calendar',20)}</span><h2>Coming up</h2></div>
     <div id="upcoming">${events.length ? events.map(upcomingItem).join('') : '<p class="small-empty">Nothing scheduled yet.</p>'}</div>
     <button class="text-button calendar-link" type="button" data-action="page" data-id="calendar">View calendar</button>
    </section>
    <section class="panel ai-panel"><div class="rail-title"><span class="tile purple">${icon('sparkles',21)}</span><h2>AI Assistant</h2></div>
      <p>Make your next conversation count.</p>
      <div class="assistant-actions">
        <button type="button" data-action="assistant" data-id="summary">${icon('messages',17)}<span>Summarize conversation</span>${icon('chevron',15)}</button>
        <button type="button" data-action="assistant" data-id="reply">${icon('edit',17)}<span>Draft a reply</span>${icon('chevron',15)}</button>
        <button type="button" data-action="assistant" data-id="next">${icon('check',17)}<span>Suggest next steps</span>${icon('chevron',15)}</button>
      </div>
      ${state.data.ai ? '' : '<div class="assistant-note">Template preview · Live AI needs setup</div>'}
    </section>
  </aside>`;
}
function messagesPage() {
  return `${hero()}<div class="dashboard">
    <section class="panel inbox-panel ${state.mobileThread ? 'thread-open' : ''}" aria-label="Messages">
      <div class="inbox">
        <div class="inbox-top"><h2>Inbox</h2>${iconButton('plus','Start a conversation','new-thread','inbox-add')}</div>
        <div class="search-wrap">${icon('search',17)}<input id="thread-search" type="search" aria-label="Search conversations" placeholder="Search messages" value="${attr(state.filter)}"></div>
        <div class="filter-row" aria-label="Filter conversations">
          ${[['all','All'],['unread','Unread'],['groups','Groups']].map(([id,label]) => `<button type="button" class="filter ${state.messageFilter === id ? 'chosen' : ''}" aria-pressed="${state.messageFilter === id}" data-action="filter" data-id="${id}">${label}</button>`).join('')}
        </div>
        <div class="thread-list" id="thread-list">${threadList()}</div>
      </div>
      <div class="conversation-area" id="conversation-area">${conversation()}</div>
    </section>
    ${rail()}
  </div>`;
}
function updateInbox() {
  const list = document.querySelector('#thread-list');
  if (list) {
    const focus = document.activeElement?.closest('[data-action="thread"]')?.dataset.id;
    list.innerHTML = threadList();
    if (focus) [...list.querySelectorAll('button')].find(button => button.dataset.id === focus)?.focus();
  }
  const events = document.querySelector('#upcoming');
  if (events) {
    const items = upcoming().slice(0,2);
    events.innerHTML = items.length ? items.map(upcomingItem).join('') : '<p class="small-empty">Nothing scheduled yet.</p>';
  }
}
function updateMessages(forceBottom) {
  const stream = document.querySelector('#message-stream');
  if (!stream) return;
  const closeToEnd = stream.scrollHeight - stream.clientHeight - stream.scrollTop < 90;
  stream.innerHTML = messageContent();
  if (forceBottom || closeToEnd) stream.scrollTop = stream.scrollHeight;
}

const dateOnly = d => [d.getFullYear(), String(d.getMonth()+1).padStart(2,'0'), String(d.getDate()).padStart(2,'0')].join('-');
const localDateTime = value => {
  const d = new Date(value);
  return dateOnly(d) + 'T' + String(d.getHours()).padStart(2,'0') + ':' + String(d.getMinutes()).padStart(2,'0');
};
function calendarPage() {
  const month = state.month;
  const first = new Date(month.getFullYear(),month.getMonth(),1);
  const count = new Date(month.getFullYear(),month.getMonth()+1,0).getDate();
  const days = Math.ceil((first.getDay() + count) / 7) * 7;
  const visibleEvents = state.data.events.filter(e => state.calendar === 'all'
    || (state.calendar === 'public' ? e.visibility === 'Public' : isAttending(e)));
  const filters = [['all','All events'],['public','Public calendar'],['private','My calendar']];
  const cells = Array.from({length:days}, (_,i) => {
    const d = new Date(month.getFullYear(),month.getMonth(),i - first.getDay() + 1);
    const day = dateOnly(d);
    const matched = visibleEvents.filter(e => dateOnly(new Date(e.starts_at)) === day);
    return `<div class="calendar-cell ${d.getMonth() !== month.getMonth() ? 'muted-day' : ''} ${day === dateOnly(new Date()) ? 'today' : ''}"><button class="cell-date" type="button" data-action="day-events" data-id="${day}" aria-label="${esc(dayText(d))}${matched.length ? ', ' + matched.length + ' events' : ''}"><span>${d.getDate()}</span><i aria-hidden="true">${matched.length ? '•' : ''}</i></button>${matched.slice(0,2).map(e => `<button class="event-tag ${e.visibility === 'Public' ? 'public-event' : ''}" type="button" data-action="event-view" data-id="${attr(e.id)}" title="${attr(e.title)}">${esc(e.title)}</button>`).join('')}${matched.length > 2 ? `<button type="button" class="more-events text-button" data-action="day-events" data-id="${day}">+${matched.length-2} more</button>` : ''}</div>`;
  }).join('');
  const agenda = visibleEvents.filter(e => {
    const d = new Date(e.starts_at);
    return d.getFullYear() === month.getFullYear() && d.getMonth() === month.getMonth();
  });
  return `<div class="page-lead"><h1>Calendar</h1><p>Plan check-ins and see what’s happening across the community.</p></div>
    <div class="calendar-layout"><section class="panel calendar-panel" aria-label="Monthly calendar">
      <div class="calendar-controls"><h2>${esc(fmt(month,{month:'long',year:'numeric'}))}</h2><div>${iconButton('left','Previous month','prev-month')}<button type="button" class="button outline compact" data-action="today">Today</button>${iconButton('chevron','Next month','next-month')}</div></div>
      <div class="calendar-filters">${filters.map(([id,label]) => `<button type="button" class="filter ${state.calendar === id ? 'chosen' : ''}" aria-pressed="${state.calendar === id}" data-action="calendar-filter" data-id="${id}">${label}</button>`).join('')}</div>
      <div class="calendar-grid"><div class="weekdays">${['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d => '<span>' + d + '</span>').join('')}</div><div class="calendar-cells">${cells}</div></div>
    </section><aside class="panel agenda"><div class="rail-title"><span class="tile green">${icon('calendar',20)}</span><h2>This month</h2></div>
    <p class="agenda-time">Times shown in ${esc(timezone())}</p>
    ${agenda.length ? agenda.map(upcomingItem).join('') : '<p class="small-empty">No events on this calendar yet.</p>'}
    <div class="legend"><span>${icon('globe',15)} Public · Workspace members</span><span>${icon('lock',15)} Private · Owner and invited guests</span></div>
    </aside></div>`;
}
function peoplePage() {
  const people = state.data.people.filter(p => p.id !== mine()?.id);
  const matches = state.data.matches || [];
  return `<div class="page-lead"><h1>People</h1><p>Find mentors and peers taking different paths into tech.</p></div>
  ${mine().role === 'Mentee' ? `<section class="panel match-panel"><h2>Recommended mentors</h2>
    ${matches.length ? '<div class="people-grid">' + matches.map(match => {
      const person = pById(match.id);
      return `<article class="panel person-card">${avatar(person,'small')}<h2>${esc(person.name)}</h2><small>@${esc(person.username)}</small><p><strong>In common</strong><br>${esc(match.common.join(', '))}${match.preferences.length ? '<br>' + esc(match.preferences.join(' · ')) : ''}</p><button type="button" class="button outline" data-action="message-person" data-id="${attr(person.id)}">Message</button></article>`;
    }).join('') + '</div>' : '<p>No shared interests found yet. Recommendations appear when a mentor shares interests with your story.</p>'}</section>` : ''}
  <div class="people-grid">${people.length ? people.map(p => `<article class="panel person-card">
  ${avatar(p,'large')}<span class="role-pill">${esc(p.role)}</span><h2>${esc(p.name)}</h2>${p.username ? '<small>@' + esc(p.username) + '</small>' : ''}<p>${esc(p.focus || 'No focus area added yet.')}</p>
  <button type="button" class="button outline" data-action="message-person" data-id="${attr(p.id)}">${icon('messages',17)} Message</button></article>`).join('') : '<div class="panel empty"><span class="tile">' + icon('users',25) + '</span><h3>No other members yet</h3><p>People appear here once they set up their profiles.</p></div>'}</div>`;
}
function render() {
  if (!mine()?.intake?.story) {
    app.innerHTML = `<main class="onboard" id="main"><section class="panel onboard-card"><img src="/mark.svg" width="48" height="48" alt=""><h1>Set up your workspace profile</h1><p>Tell other members how you’re taking part in TechWomen AZ.</p>
    ${profileFields(mine())}${state.auth?.accounts
      ? '<button type="button" class="text-button" data-action="account-signout">Sign out</button>'
      : ''}</section></main>`;
    return;
  }
  app.innerHTML = `${sidebar()}${state.menu ? '<button class="scrim" data-action="menu" type="button" aria-label="Close workspace navigation"></button>' : ''}<div class="shell">${header()}<main class="main" id="main">${{messages:messagesPage,calendar:calendarPage,people:peoplePage}[state.page]()}</main></div>`;
  updateBadges();
  const stream = document.querySelector('#message-stream');
  if (stream) stream.scrollTop = stream.scrollHeight;
}

function openModal(title, html) {
  modal.innerHTML = `<div class="modal-head"><h2 id="modal-title">${esc(title)}</h2>${iconButton('close','Close dialog','close')}</div>${html}`;
  if (!modal.open) modal.showModal();
  modal.scrollTop = 0;
}
function formError(form, error) {
  const target = form.querySelector('.form-error');
  if (target) target.textContent = error.message;
  else toast(error.message);
}
const formErrorLine = '<p class="form-error" role="status"></p>';
const cancel = '<button type="button" class="button outline" data-action="close">Cancel</button>';
function checkPeople(people, selected) {
  return people.map(p => `<label class="person-choice" data-username="${attr(p.username || '')}"><input type="checkbox" name="person" value="${attr(p.id)}" ${selected.includes(p.id) ? 'checked' : ''}>${avatar(p,'tiny')}<span><strong>${esc(p.name)}</strong><small>${p.username ? '@' + esc(p.username) + ' · ' : ''}${esc(p.role)}</small></span></label>`).join('');
}
function newThread(preselect) {
  const participants = state.data.people.filter(p => p.id !== mine().id && p.username);
  openModal('New message', `<form id="new-thread-form" class="dialog-form" data-request="${crypto.randomUUID()}"><p>Find people by username. Include at least one mentor and one mentee.</p>
      <label>Username<input id="recipient-search" type="search" placeholder="@username" autocomplete="off"></label>
      <fieldset class="choices"><legend>Recipients</legend>${checkPeople(participants,preselect ? [preselect] : [])}<p id="recipient-status" role="status"></p></fieldset>
      <label>Group name <span class="hint">(for 3 or more people)</span><input name="title" maxlength="80" placeholder="e.g. Career switch support"></label>
      ${formErrorLine}<div class="form-actions">${cancel}<button class="button primary" type="submit">Start conversation</button></div></form>`);
  filterRecipients(modal.querySelector('#recipient-search'));
}
function filterRecipients(search) {
  const username = search.value.trim().toLowerCase().replace(/^@/, '');
  let matches = 0;
  for (const choice of search.form.querySelectorAll('[data-username]')) {
    const match = Boolean(username && choice.dataset.username.startsWith(username));
    choice.hidden = !match && !choice.querySelector('input').checked;
    if (match) matches++;
  }
  search.form.querySelector('#recipient-status').textContent = username && !matches ? 'No matching usernames.' : '';
}
function profileFields(p) {
  const intake = p?.intake || {};
  const options = (values, selected) => '<option value="">Choose one</option>' + values.map(value => `<option ${value === selected ? 'selected' : ''}>${value}</option>`).join('');
  return `<form id="profile-form" class="dialog-form" novalidate>
    <section class="intake-step" data-intake="0"><h2>What should we call you?</h2>
    <label>Name<input name="name" maxlength="60" required value="${attr(p?.name || state.data.signedIn.name)}"></label>
    <label>Preferred name<input name="preferred" maxlength="60" required value="${attr(intake.preferred || state.accountPreferred)}"></label>
    <label>Username<input name="username" minlength="3" maxlength="24" pattern="[A-Za-z0-9_]{3,24}" required value="${attr(p?.username)}" placeholder="e.g. alex_r"></label>
    </section>
    <section class="intake-step" data-intake="1" hidden><h2>How would you like to connect?</h2>
    <label>Role<select name="role"><option value="Mentee" ${p?.role === 'Mentee' ? 'selected' : ''}>Mentee</option><option value="Mentor" ${p?.role === 'Mentor' ? 'selected' : ''}>Mentor</option></select></label>
    <label>Mentoring style<select name="style" required>${options(['One-on-one','Group','Either'],intake.style)}</select></label>
    </section>
    <section class="intake-step" data-intake="2" hidden><h2>Where would you like to meet?</h2>
    <label>Meeting preference<select name="format" required>${options(['In person','Online','Either'],intake.format)}</select></label>
    </section>
    <section class="intake-step" data-intake="3" hidden><h2>Tell us your story</h2><p id="story-prompt"></p>
    <label>Focus area <span class="hint">(optional)</span><input name="focus" maxlength="120" placeholder="e.g. Business to product design" value="${attr(p?.focus)}"></label>
    <label>Your story<textarea required name="story" maxlength="2500" rows="5">${esc(intake.story)}</textarea></label>
    <p class="hint">Your story helps find matches. People see the shared topics instead of your full story.</p></section>
    ${formErrorLine}<div class="form-actions">${p?.intake?.story ? cancel : ''}<button class="button outline" type="button" data-action="intake-back" hidden>Back</button><button class="button primary" type="submit">Continue</button></div></form>`;
}
function showIntake(form, index) {
  form.querySelectorAll('[data-intake]').forEach(section => { section.hidden = Number(section.dataset.intake) !== index; });
  form.querySelector('[data-action="intake-back"]').hidden = index === 0;
  form.querySelector('[type="submit"]').textContent = index === 3 ? 'Save profile' : 'Continue';
  if (index === 3) {
    const style = form.elements.style.value;
    const format = form.elements.format.value;
    const stylePrompt = {
      'One-on-one':'What would make a one-on-one conversation valuable to you?',
      Group:'What would you like to learn or share with a mentoring group?',
      Either:'What kind of mentoring support would suit you best?',
    };
    const formatPrompt = {
      'In person':'If location matters, share your general area.',
      Online:'If you have a favorite way to collaborate online, mention it.',
      Either:'',
    };
    const background = form.elements.role.value === 'Mentor'
      ? 'What’s your path into tech, what topics can you mentor on, and which projects have shaped your experience?'
      : 'What brought you to tech, what interests you, and what would you like your mentor to help you with?';
    form.querySelector('#story-prompt').textContent = [background,stylePrompt[style],formatPrompt[format]].filter(Boolean).join(' ');
  }
  form.querySelector('[data-intake="' + index + '"] h2').setAttribute('tabindex','-1');
  form.querySelector('[data-intake="' + index + '"] h2').focus();
}
function profileMenu() {
  const demo = state.mode === 'demo';
  const samplePeople = state.data.people.filter(p => !p.isDemoAccount);
  const accountStatus = state.data.signedIn;
  openModal('Workspace profile', `<div class="dialog-form">
    <div class="profile-header">${avatar(mine(),'medium')}<div><strong>${esc(mine().name)}</strong><p>@${esc(mine().username)} · ${esc(mine().role)}</p></div></div>
    ${demo && !mine().isDemoAccount ? `<p>Switch between sample mentors and mentees to try both sides of a conversation.</p><div class="profile-options">${samplePeople.map(p => `<button type="button" data-action="switch-person" data-id="${p.id}">${avatar(p,'tiny')}<span>${esc(p.name)}<small>${esc(p.role)}</small></span>${p.id === mine().id ? icon('check',17) : ''}</button>`).join('')}</div>` : ''}
    <button type="button" class="button outline" data-action="profile-edit">${icon('edit',17)} Edit profile</button>
    ${accountStatus.accounts ? accountStatus.googleLinked
      ? '<p class="google-connected">' + icon('check',17) + ' Google account connected</p>'
      : googleButton(accountStatus.googleAvailable,true) : ''}
    ${state.auth?.accounts ? '<button type="button" class="text-button" data-action="account-signout">Sign out</button>' : ''}</div>`);
}
const reminders = [[0,'No reminder'],[5,'5 minutes before'],[10,'10 minutes before'],[15,'15 minutes before'],[30,'30 minutes before'],[60,'1 hour before'],[1440,'1 day before']];
function eventForm(e, guests = [], day = '', fromThread = false) {
  const soon = new Date(Math.ceil((Date.now() + 60000) / 1800000) * 1800000);
  if (day) {
    const [y,m,d] = day.split('-').map(Number);
    soon.setFullYear(y,m-1,d);
    soon.setHours(10,0,0,0);
  }
  const starts = e?.starts_at || soon.getTime();
  const ends = e?.ends_at || starts + 30 * 60000;
  const format = e?.format || 'Online';
  const people = state.data.people.filter(p => p.id !== mine().id);
  openModal(e ? 'Edit event' : fromThread ? 'Schedule a follow-up' : 'New event', `<form class="dialog-form" id="event-form" data-id="${attr(e?.id)}" data-request="${crypto.randomUUID()}">
    <label>Event title<input required name="title" maxlength="100" placeholder="e.g. Portfolio check-in" value="${attr(e?.title)}"></label>
    <div class="form-grid"><label>Starts<input type="datetime-local" name="start" required value="${localDateTime(starts)}"></label>
    <label>Ends<input type="datetime-local" name="end" required value="${localDateTime(ends)}"></label></div>
    <div class="hint">Time zone · ${esc(timezone())}</div>
    <div class="form-grid"><label>Meeting format<select name="format"><option ${format === 'Online' ? 'selected' : ''}>Online</option><option ${format === 'In person' ? 'selected' : ''}>In person</option></select></label>
    <label>Visibility<select name="visibility"><option ${e?.visibility === 'Private' ? '' : e?.visibility ? '' : 'selected'}>Private</option><option ${e?.visibility === 'Public' ? 'selected' : ''}>Public</option></select></label></div>
    <p class="hint" id="visibility-note">${e?.visibility === 'Public' ? 'Visible to everyone in this workspace.' : 'Visible to you and the people you invite.'}</p>
    <label><span id="location-label">${format === 'Online' ? 'Meeting link' : 'Location'} <span class="hint">(optional)</span></span><input name="location" maxlength="240" placeholder="${format === 'Online' ? 'https://…' : 'Address or meeting place'}" value="${attr(e?.location)}"></label>
    <label>Remind me and invited guests<select name="reminder">${reminders.map(([key,label]) => `<option value="${key}" ${(e?.reminder ?? 30) === key ? 'selected' : ''}>${label}</option>`).join('')}</select></label>
    ${people.length ? '<details class="guest-picker"' + (guests.length ? ' open' : '') + '><summary>Invite people (optional)</summary><div class="choices">' + checkPeople(people,guests) + '</div></details>' : ''}
    <label>Notes <span class="hint">(optional)</span><textarea name="notes" maxlength="1000" rows="2" placeholder="What should people bring or prepare?">${esc(e?.notes)}</textarea></label>
    ${formErrorLine}<div class="form-actions">${cancel}<button type="submit" class="button primary">${e ? 'Save changes' : 'Save event'}</button></div></form>`);
}
const googleStamp = value => new Date(value).toISOString().replace(/[-:]/g,'').replace(/\.\d{3}Z$/,'Z');
function googleUrl(e) {
  return 'https://calendar.google.com/calendar/render?' + new URLSearchParams({
    action:'TEMPLATE',text:e.title,dates:googleStamp(e.starts_at) + '/' + googleStamp(e.ends_at),details:e.notes,
    location:e.location,
  });
}
const calText = value => String(value).replace(/\\/g,'\\\\').replace(/\r\n|\r|\n/g,'\\n').replace(/([,;])/g,'\\$1');
function foldCalendarLine(line) {
  const encoder = new TextEncoder();
  const chunks = [];
  let current = '', size = 0;
  for (const character of line) {
    const bytes = encoder.encode(character).length;
    if (size + bytes > 75) {
      chunks.push(current);
      current = ' ';
      size = 1;
    }
    current += character;
    size += bytes;
  }
  chunks.push(current);
  return chunks.join('\r\n');
}
function downloadEvent(e) {
  const lines = ['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//TechWomen AZ//Mentoring Workspace//EN','BEGIN:VEVENT',
    'UID:' + calText(e.id) + '@techwomen-az', 'DTSTAMP:' + googleStamp(Date.now()), 'DTSTART:' + googleStamp(e.starts_at), 'DTEND:' + googleStamp(e.ends_at),
    'SUMMARY:' + calText(e.title),'DESCRIPTION:' + calText(e.notes),'LOCATION:' + calText(e.location), 'CLASS:' + e.visibility.toUpperCase()];
  if (e.reminder) lines.push('BEGIN:VALARM','TRIGGER:-PT' + e.reminder + 'M','ACTION:DISPLAY','DESCRIPTION:' + calText(e.title),'END:VALARM');
  lines.push('END:VEVENT','END:VCALENDAR');
  const url = URL.createObjectURL(new Blob([lines.map(foldCalendarLine).join('\r\n') + '\r\n'],{type:'text/calendar;charset=utf-8'}));
  const a = document.createElement('a');
  a.href = url;
  a.download = 'techwomen-az-event.ics';
  a.click();
  setTimeout(() => URL.revokeObjectURL(url),1000);
}
function showEvent(e) {
  if (!e) return;
  const details = [
    ['clock',dayText(e.starts_at) + ' · ' + shortTime(e.starts_at) + ' to ' + (dayKey(e.starts_at) === dayKey(e.ends_at) ? '' : dayText(e.ends_at) + ' ') + shortTime(e.ends_at) + ' ' + timezone()],
    [e.format === 'Online' ? 'video' : 'pin',e.format + (e.format === 'In person' && e.location ? ' · ' + e.location : '')],
    [e.visibility === 'Public' ? 'globe' : 'lock',e.visibility === 'Public' ? 'Public · Workspace members' : 'Private · Owner and invited guests'],
    ...(isAttending(e) && e.reminder ? [['bell',reminders.find(([minutes]) => minutes === e.reminder)?.[1] || 'Reminder set']] : []),
  ];
  const guests = e.guests.map(id => pById(id)?.name).filter(Boolean);
  openModal(e.title,`<div class="dialog-form event-details">
    <div class="detail-list">${details.map(([symbol,label]) => `<p>${icon(symbol,18)}<span>${esc(label)}</span></p>`).join('')}</div>
    ${e.notes ? '<p class="event-notes">' + esc(e.notes) + '</p>' : ''}${guests.length ? '<p class="hint">Invited · ' + esc(guests.join(', ')) + '</p>' : ''}
    <div class="event-links">
      ${e.format === 'Online' && /^https:\/\//i.test(e.location) ? `<a class="button primary" href="${attr(e.location)}" target="_blank" rel="noopener noreferrer">${icon('video',17)} Join online</a>` : ''}
      <a class="button outline" href="${attr(googleUrl(e))}" target="_blank" rel="noopener noreferrer">${icon('calendar',17)} Add to Google Calendar</a>
      <button type="button" class="button outline" data-action="event-download" data-id="${attr(e.id)}">${icon('download',17)} Download calendar file</button>
    </div>
    ${e.owner_id === mine().id ? `<div class="form-actions"><button type="button" class="text-button danger" data-action="event-remove" data-id="${attr(e.id)}">Delete event</button><button type="button" class="button outline" data-action="event-edit" data-id="${attr(e.id)}">${icon('edit',17)} Edit event</button></div>` : ''}
    </div>`);
}
function reminderMenu() {
  const reminders = dueReminders();
  openModal('Reminders', `<div class="dialog-form">${reminders.length ? reminders.map(e => `<div class="reminder-line">${upcomingItem(e)}<button type="button" class="text-button" data-action="dismiss" data-id="${attr(e.id)}">Mark as read</button></div>`).join('')
  : '<div class="empty"><span class="tile">' + icon('bell',24) + '</span><h3>You’re caught up</h3><p>Meeting reminders appear here at the time you choose.</p></div>'}</div>`);
}
async function assistant(task, confirmed = false) {
  const thread = activeThread();
  if (!thread) return toast('Open a conversation first.');
  const label = {summary:'Summarize conversation',reply:'Draft a reply',next:'Suggest next steps'}[task];
  if (state.data.ai && !confirmed) {
    openModal(label, `<div class="dialog-form"><p>The assistant uses up to 20 recent messages in this conversation to generate a suggestion.</p><div class="form-actions">${cancel}<button type="button" class="button primary" data-action="assistant-confirm" data-id="${task}">Generate</button></div></div>`);
    return;
  }
  openModal(label, '<div class="dialog-form" aria-busy="true"><p>Preparing your suggestion…</p></div>');
  const marker = modal.querySelector('.dialog-form');
  try {
    const result = await api('assistant',{thread:thread.id,task});
    if (!modal.open || modal.querySelector('.dialog-form') !== marker) return;
    openModal(label, `<div class="dialog-form"><p class="hint">${result.source === 'ai' ? 'AI suggestion · Review before sharing' : 'Built-in template preview'}</p><div id="assistant-result" class="assistant-result">${esc(result.text)}</div><div class="form-actions">
      <button type="button" class="button outline" data-action="copy-assistant">${icon('copy',16)} Copy</button>
      ${task === 'reply' ? '<button type="button" class="button primary" data-action="use-draft">Use as draft</button>' : ''}
      </div></div>`);
  } catch (error) {
    if (modal.open && modal.querySelector('.dialog-form') === marker) openModal(label, '<div class="dialog-form"><p role="status">' + esc(error.message) + '</p></div>');
  }
}

async function selectThread(id) {
  state.active = id;
  state.page = 'messages';
  state.mobileThread = true;
  state.messages = [];
  state.loadingThread = true;
  render();
  await loadMessages({forceBottom:true});
}
async function changeWorkspace(mode, person = 'avery') {
  state.mode = mode;
  state.as = person;
  storage.set('tw.mode',mode);
  storage.set('tw.as',person);
  Object.assign(state,{page:'messages',active:null,messages:[],filter:'',messageFilter:'all',menu:false,mobileThread:false,drafts:new Map()});
  if (modal.open) modal.close();
  await refresh({full:true});
  await loadMessages({forceBottom:true});
}
function dayEvents(day) {
  const events = state.data.events.filter(e => dateOnly(new Date(e.starts_at)) === day &&
    (state.calendar === 'all' || (state.calendar === 'public' ? e.visibility === 'Public' : isAttending(e))));
  openModal(dayText(new Date(day + 'T12:00')),`<div class="dialog-form">
    ${events.length ? events.map(upcomingItem).join('') : '<p>No events on this day.</p>'}
    <div class="form-actions"><button type="button" class="button primary" data-action="event-on-day" data-id="${day}">${icon('plus',16)} New event</button></div></div>`);
}
const findEvent = id => state.data.events.find(e => e.id === id);
const actions = {
  page: async id => {
    state.page = id;
    state.menu = false;
    state.mobileThread = false;
    render();
    if (id === 'messages') await loadMessages({mark:false});
  },
  menu: () => { state.menu = !state.menu; render(); },
  back: () => { state.mobileThread = false; render(); },
  thread: selectThread,
  filter: id => {
    state.messageFilter = id;
    document.querySelectorAll('[data-action="filter"]').forEach(button => {
      button.classList.toggle('chosen', button.dataset.id === id);
      button.setAttribute('aria-pressed',button.dataset.id === id);
    });
    updateInbox();
  },
  'new-thread': () => newThread(),
  'message-person': newThread,
  'profile-menu': profileMenu,
  'profile-edit': () => openModal('Edit profile',profileFields(mine())),
  'intake-back': () => {
    const form = document.querySelector('#profile-form');
    showIntake(form,Number(form.querySelector('[data-intake]:not([hidden])').dataset.intake)-1);
  },
  'switch-person': id => state.auth?.offline ? openDemoAccount(id) : changeWorkspace('demo',id),
  'switch-demo': () => changeWorkspace('demo'),
  'switch-live': () => changeWorkspace('live'),
  'account-switch': kind => {
    state.accountKind = kind;
    state.accountNotice = '';
    return renderAccountGate(true);
  },
  'account-signout': accountSignOut,
  'google-info': () => openModal('Google sign-in', '<div class="dialog-form"><p>Google sign-in is available when TechWomen AZ runs on a server configured with a Google OAuth client.</p><div class="form-actions"><button type="button" class="button primary" data-action="close">Done</button></div></div>'),
  close: () => modal.close(),
  'event-new': () => eventForm(null),
  'thread-event': () => eventForm(null,activeThread().members.filter(id => id !== mine().id),'',true),
  'event-view': id => showEvent(findEvent(id)),
  'event-edit': id => { const e = findEvent(id); if (e) eventForm(e,e.guests); },
  'event-download': id => { const e = findEvent(id); if (e) downloadEvent(e); },
  'event-remove': id => openModal('Delete this event?',`<div class="dialog-form"><p>It will be removed from the workspace calendar and from invited guests’ schedules.</p><div class="form-actions">${cancel}<button type="button" class="button destructive" data-action="event-remove-confirm" data-id="${attr(id)}">Delete event</button></div></div>`),
  'event-remove-confirm': async id => {
    await api('delete-event',{id}); modal.close(); await refresh({full:true}); toast('Event deleted.');
  },
  'calendar-filter': id => { state.calendar = id; render(); document.querySelector('[data-action="calendar-filter"][data-id="' + id + '"]')?.focus(); },
  'prev-month': () => moveMonth(-1,'prev-month'),
  'next-month': () => moveMonth(1,'next-month'),
  today: () => {
    state.month = new Date(new Date().getFullYear(),new Date().getMonth(),1);
    render(); document.querySelector('[data-action="today"]')?.focus();
  },
  'day-events': dayEvents,
  'event-on-day': day => eventForm(null,[],day),
  reminders: reminderMenu,
  dismiss: async id => { await api('dismiss',{id}); await refresh(); reminderMenu(); },
  assistant: id => assistant(id),
  'assistant-confirm': id => assistant(id,true),
  'copy-assistant': async () => {
    const result = document.querySelector('#assistant-result');
    try {
      await navigator.clipboard.writeText(result.textContent);
      toast('Copied.');
    } catch {
      const range = document.createRange();
      range.selectNodeContents(result);
      window.getSelection().removeAllRanges();
      window.getSelection().addRange(range);
      toast('Text selected. Press Ctrl+C to copy.');
    }
  },
  'use-draft': () => {
    const text = document.querySelector('#assistant-result').textContent;
    const existing = state.drafts.get(state.active);
    const merged = existing ? existing + '\n\n' + text : text;
    const draft = document.querySelector('#draft');
    state.drafts.set(state.active, merged.slice(0,3000));
    modal.close();
    if (draft) { draft.value = state.drafts.get(state.active); draft.focus(); }
  },
};
function moveMonth(amount, action) {
  state.month = new Date(state.month.getFullYear(),state.month.getMonth() + amount,1);
  render();
  document.querySelector('[data-action="' + action + '"]')?.focus();
}
document.addEventListener('click', async event => {
  const button = event.target.closest('button[data-action]');
  if (!button || !Object.hasOwn(actions,button.dataset.action)) return;
  if (button.dataset.action === 'event-remove-confirm') button.disabled = true;
  try { await actions[button.dataset.action](button.dataset.id); }
  catch (error) { toast(error.message); }
  finally { if (button.isConnected) button.disabled = false; }
});
document.addEventListener('input', event => {
  if (event.target.id === 'recipient-search') filterRecipients(event.target);
  if (event.target.id === 'thread-search') {
    state.filter = event.target.value;
    updateInbox();
  }
  if (event.target.id === 'draft') state.drafts.set(state.active,event.target.value);
});
document.addEventListener('change', event => {
  const form = event.target.form;
  if (form?.id !== 'event-form') return;
  if (event.target.name === 'format') {
    const online = event.target.value === 'Online';
    form.querySelector('#location-label').firstChild.textContent = online ? 'Meeting link ' : 'Location ';
    form.elements.location.placeholder = online ? 'https://…' : 'Address or meeting place';
  }
  if (event.target.name === 'visibility') form.querySelector('#visibility-note').textContent = event.target.value === 'Public'
    ? 'Visible to everyone in this workspace.' : 'Visible to you and the people you invite.';
  if (event.target.name === 'start' && form.elements.start.value >= form.elements.end.value) {
    const start = new Date(form.elements.start.value).getTime();
    if (Number.isFinite(start)) form.elements.end.value = localDateTime(start + 1800000);
  }
});
document.addEventListener('keydown', event => {
  if (event.target.id === 'draft' && event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
    event.preventDefault();
    event.target.form.requestSubmit();
  }
});
const pendingMessages = new Map();
document.addEventListener('submit', async event => {
  const form = event.target;
  if (!['account-form','composer','event-form','new-thread-form','profile-form'].includes(form.id)) return;
  event.preventDefault();
  const button = form.querySelector('button[type="submit"]');
  if (button.disabled) return;
  const fields = new FormData(form);
  button.disabled = true;
  const errorLine = form.querySelector('.form-error');
  if (errorLine) errorLine.textContent = '';
  try {
    if (form.id === 'account-form') {
      const details = Object.fromEntries(fields);
      const create = form.dataset.kind === 'register';
      if (create) state.accountPreferred = details.preferred;
      if (state.auth.offline) {
        const account = await demoApi(null,create ? 'demo-register' : 'demo-sign-in',details);
        if (account.id) await openDemoAccount(account.id);
      } else {
        await authPost(create ? 'register' : 'sign-in',details);
        state.auth.signedIn = true;
        await changeWorkspace('live');
      }
      return;
    }
    if (form.id === 'composer') {
      const id = state.active;
      const draft = form.querySelector('#draft');
      const text = draft.value.trim();
      if (!text) return;
      const retry = pendingMessages.get(id);
      const messageId = retry?.text === text ? retry.id : crypto.randomUUID();
      pendingMessages.set(id,{text,id:messageId});
      await api('send',{thread:id,message:text,id:messageId});
      pendingMessages.delete(id);
      if (state.drafts.get(id)?.trim() === text) {
        state.drafts.delete(id);
        draft.value = '';
      }
      if (state.active === id) {
        await loadMessages({forceBottom:true});
        draft.focus();
      }
      await refresh();
    }
    if (form.id === 'new-thread-form') {
      const result = await api('new-thread',{title:fields.get('title'),people:fields.getAll('person'),requestId:form.dataset.request});
      modal.close();
      state.active = result.id;
      await refresh();
      await selectThread(result.id);
    }
    if (form.id === 'event-form') {
      const result = await api('event',{
        id:form.dataset.id || undefined,requestId:form.dataset.request,title:fields.get('title'),starts_at:new Date(fields.get('start')).getTime(),
        ends_at:new Date(fields.get('end')).getTime(),format:fields.get('format'),visibility:fields.get('visibility'),
        reminder:Number(fields.get('reminder')),location:fields.get('location'),notes:fields.get('notes'),guests:fields.getAll('person'),
      });
      await refresh({full:state.page === 'calendar'});
      showEvent(findEvent(result.id));
      toast('Event saved.');
    }
    if (form.id === 'profile-form') {
      const index = Number(form.querySelector('[data-intake]:not([hidden])').dataset.intake);
      for (const input of form.querySelectorAll('[data-intake]:not([hidden]) input, [data-intake]:not([hidden]) select, [data-intake]:not([hidden]) textarea')) {
        if (!input.reportValidity()) return;
      }
      if (index < 3) { showIntake(form,index+1); return; }
      const onboarding = !mine()?.intake?.story;
      await api('profile',Object.fromEntries(fields));
      if (modal.open) modal.close();
      if (onboarding) state.page = fields.get('role') === 'Mentor' ? 'messages' : 'people';
      await refresh({full:true});
      toast('Profile saved.');
    }
  } catch (error) { formError(form,error); }
  finally { button.disabled = false; }
});

modal.addEventListener('click', event => {
  if (event.target !== modal) return;
  const bounds = modal.getBoundingClientRect();
  if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) modal.close();
});

async function initialize() {
  if (demoApi) {
    const person = storage.get('tw.demo.session');
    state.auth = {accounts:true,offline:true,signedIn:!!person,googleAvailable:false};
    state.accountKind = 'register';
    if (person) {
      state.mode = 'demo';
      state.as = person;
    }
  } else {
    state.auth = await getAuthStatus();
    if (state.auth?.accounts) {
      state.mode = 'live';
      const callback = new URLSearchParams(location.search).get('auth');
      state.accountKind = callback ? 'sign-in' : 'register';
      if (callback) {
        state.accountNotice = googleNotices[callback] || '';
        history.replaceState(null,'',location.pathname);
      }
    }
  }
  if (state.auth?.accounts && !state.auth.signedIn) {
    await renderAccountGate();
    return;
  }
  await refresh({full:true});
  await loadMessages({mark:false,forceBottom:true});
  if (state.accountNotice) toast(state.accountNotice);
}
try { await initialize(); }
catch (error) {
  if (state.auth?.offline && state.auth.signedIn) {
    await accountSignOut();
  } else {
    app.innerHTML = `<main class="onboard" id="main"><section class="panel onboard-card"><img src="/mark.svg" width="45" height="45" alt=""><h1>TechWomen AZ</h1><p>${esc(error.message)}</p>
      ${error.status === 401 ? '<a class="button primary" href="/signin-with-chatgpt?return_to=%2F" target="_top">Sign in with ChatGPT</a>' : '<a class="button primary" href="/">Try again</a>'}</section></main>`;
  }
}
let checking = false;
setInterval(async () => {
  if (document.hidden || !state.data || checking) return;
  checking = true;
  try {
    await refresh();
    await loadMessages({mark:!modal.open && (state.mobileThread || matchMedia('(min-width: 761px)').matches)});
  } catch (error) {
    if (state.auth?.accounts && !state.auth.offline && error.status === 401 && state.data) {
      refreshCount++;
      Object.assign(state,{data:null,active:null,messages:[],drafts:new Map(),accountKind:'sign-in',accountNotice:'Your session ended. Sign in again to continue.'});
      state.auth.signedIn = false;
      if (modal.open) modal.close();
      await renderAccountGate();
    } else updateBadges();
  } finally {
    checking = false;
  }
}, 5500);
