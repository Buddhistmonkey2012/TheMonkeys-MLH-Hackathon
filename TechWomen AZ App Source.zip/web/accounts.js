const googleMark = '<svg aria-hidden="true" width="18" height="18" viewBox="0 0 48 48"><path fill="#4285F4" d="M43.6 24.5c0-1.4-.1-2.8-.4-4.1H24v7.8h11a9.4 9.4 0 0 1-4.1 6.1v5.1h6.6c3.9-3.6 6.1-8.8 6.1-14.9z"/><path fill="#34A853" d="M24 44c5.5 0 10.1-1.8 13.5-4.6l-6.6-5.1c-1.8 1.2-4.2 1.9-6.9 1.9-5.3 0-9.8-3.6-11.4-8.4H5.8V33A20 20 0 0 0 24 44z"/><path fill="#FBBC05" d="M12.6 27.8a12 12 0 0 1 0-7.6V15H5.8a20 20 0 0 0 0 18z"/><path fill="#EA4335" d="M24 11.8c3 0 5.7 1 7.8 3.1l5.8-5.8A19.2 19.2 0 0 0 24 4 20 20 0 0 0 5.8 15l6.8 5.2c1.6-4.8 6.1-8.4 11.4-8.4z"/></svg>';

export function googleButton(available, link = false) {
  const text = link ? 'Connect Google account' : 'Continue with Google';
  if (available) return `<a class="google-button" href="/auth/google${link ? '?link=1' : ''}" target="_top">${googleMark}${text}</a>`;
  return `<button class="google-button" type="button" data-action="google-info">${googleMark}${text}</button>`;
}

export function accountScreen({offline,kind,accounts,available,notice},esc) {
  const create = kind === 'register';
  const heading = create ? 'Create your account' : 'Sign in';
  const subtitle = offline
    ? 'Create a profile to try the workspace. Your accounts stay in this browser.'
    : create ? 'Join TechWomen AZ’s mentoring workspace.' : 'Welcome back to TechWomen AZ.';
  const email = '<label>Email address<input name="email" type="email" autocomplete="email" maxlength="254" required placeholder="you@example.com"></label>';
  const password = create
    ? '<label>Password<input type="password" name="password" minlength="12" maxlength="128" required aria-describedby="password-hint" autocomplete="new-password"><span class="hint" id="password-hint">Use at least 12 characters.</span></label>'
    : '<label>Password<input type="password" name="password" maxlength="128" required autocomplete="current-password"></label>';
  const name = '<label>Full name<input name="name" maxlength="60" autocomplete="name" required placeholder="Your name"></label>';
  const demoName = '<label>Display name<input name="name" maxlength="60" autocomplete="off" required placeholder="e.g. Alex Rivera"></label>';
  const role = '<label>I’m joining as a<select name="role"><option>Mentee</option><option>Mentor</option></select></label>';
  const saved = '<label>Demo account<select name="person" required><option value="">Choose an account</option>' +
    accounts.map(p => `<option value="${esc(p.id)}">${esc(p.name)} · ${esc(p.role)}</option>`).join('') + '</select></label>';
  const preferred = '<label>What would you like to be called?<input name="preferred" required maxlength="60" autocomplete="nickname"></label>';
  const demoEmail = '<label>Sample email address<input name="email" type="email" maxlength="254" required placeholder="you@example.com"></label>';
  const fields = offline ? create ? demoName + preferred + demoEmail + '<label>Username<input name="username" minlength="3" maxlength="24" pattern="[A-Za-z0-9_]{3,24}" required placeholder="e.g. alex_r"></label>' + role : saved + demoEmail : (create ? name + preferred : '') + email + password;
  return `<main class="auth-shell" id="main">
    <div class="auth-story">
      <div class="brand"><img src="/mark.svg" alt="" width="43" height="43"><div><strong>TechWomen</strong><span>ARIZONA</span></div></div>
      <div class="auth-story-text"><h2>Find your path<br>into tech.</h2><p>Connect with mentors, build a plan, and make time for your next step.</p></div>
      <div class="hero-art" aria-hidden="true"><i class="ring r1"></i><i class="ring r2"></i><i class="ring r3"></i><b class="star main-star">✦</b><b class="star small-star">✦</b><i class="orbit-dot"></i></div>
    </div>
    <section class="auth-main" aria-labelledby="auth-title"><div class="auth-card">
      <h1 id="auth-title" tabindex="-1">${heading}</h1><p class="auth-subtitle">${subtitle}</p>
      <div class="auth-methods">${googleButton(available)}</div>
      <div class="auth-divider"><span>${offline ? 'or try a demo account' : 'or use your email'}</span></div>
      <form id="account-form" class="dialog-form auth-form" data-kind="${kind}">
        ${fields}
        <p class="form-error" role="alert">${esc(notice)}</p>
        <button class="button primary" type="submit" ${offline && !create && accounts.length === 0 ? 'disabled' : ''}>${create ? 'Create account' : 'Sign in'}</button>
      </form>
      <p class="auth-toggle">${create ? 'Already have an account?' : 'New to TechWomen AZ?'} <button class="text-button" type="button" data-action="account-switch" data-id="${create ? 'sign-in' : 'register'}">${create ? 'Sign in' : 'Create an account'}</button></p>
    </div></section>
  </main>`;
}
